//************************************************************************************************/
//Run with make file!
//IMP NOTE: This code can easily be manipulated to fit the traditional rules of the playfair cipher.
//(ie. to encode shift right if in same row, shift down if in same col)
//RULES:
//to Encrypt:
//add spaces to pair letters together
//add xs to separate repeating letters (ll, oo) only if they are paired togethe)
//replace j with i
//shift right if in same col
//shift down if in same row
//if neither col nor row are same, switch the col numbers but not row
//print without spaces
//to Decrypt:
//add spaces to the cyphertext so you can reverse engineer it
//(don't add xs or try to remove them)
//shift left if in same col
//shift up if in same row
//if neight col nor row are the same, switch the col numbers but not row
//print without spaces
//user will have to manually remove X's or replace I's that dont make any sense
//***************************************************************************************************/
import java.util.*;
public class Playfair {
    //Calls functions;
    public static void main (String [] args){
        String function = args[0];
        String text = args [1];
        String key = args [2];
        key = key.toLowerCase();
        char [] [] cipher = parseCipher (key);
        // for (int i =0; i < 5; i++){
        //     for (int j =0; j < 5; j++){
        //         System.out.print(cipher[i][j]);
        //     }
        //     System.out.print('\n');
        // }
        //char [] [] cipher = {
        //{'a', 'b', 'c', 'd', 'e'}, 
        //{'f', 'g', 'h', 'i', 'k'}, 
        //{'l', 'm','n', 'o', 'p'},
        //{'q', 'r', 's', 't', 'u'}, 
        //{'v', 'w', 'x', 'y', 'z'} 
    //};
        if (function.equals("encode")) encode (text, cipher);
        if (function.equals("decode")) decode (text, cipher);
    }
    //PARSES KEY TO MAKE AN DOUBLE ARRAY CALLED CIPHER    
    public static char [] [] parseCipher (String s){
        char [] [] cipher = new char [5] [5];
        int index = 0;
        //if (!(s.length() == 25)) throw new IllegalAccessException("Please enter a valid key of length 25 characters");
        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++){
                cipher [i][j] = s.charAt(index);
                index++;
            }
        }
        return cipher;
    }
    //ENCODES TEXT
    public static void encode (String plaintext, char [][] cipher){
        plaintext = plaintext.toLowerCase();
        plaintext = plaintext.replace (" ", "");
        plaintext = plaintext.replace ("j", "i");
        plaintext = add_exs (plaintext);
        //System.out.println (plaintext);

        String cyphertext = "";

        for (int i =0; i < plaintext.length(); i=i+3){
            String str = plaintext.substring (i, i +2);
            ArrayList <Integer> coords = get_cols_rows(str, cipher);
            //System.out.println(str + " " + coords);
            if (coords.get(1) == coords.get(3)) {
                // System.out.println("The columns are the same!");
                // System.out.println("Shifting to the right (down a column)");
                // System.out.println (horizontalEncode(coords, cipher));
                cyphertext = cyphertext + horizontalEncode(coords, cipher) + " "; //if the columns of the chars are the same, shift them RIGHT
            } 
            else{
                if (coords.get(0)== coords.get(2)){
                    // System.out.println("The rows are the same!");
                    // System.out.println("Shifting down a row");
                    // System.out.println (verticalEncode(coords, cipher));
                    cyphertext = cyphertext + verticalEncode(coords, cipher) + " ";// if the row of the chars are the same, shift them DOWN

                }
                else{
                    // System.out.println("The rows and columns are not same, it's a rectangle!");
                    // System.out.println("Switching the columns of each letter, but not the row!");
                    // System.out.println (regularEncode(coords, cipher));
                    cyphertext = cyphertext + regularEncode(coords, cipher) + " ";}
             }
             //System.out.println ("cyphertext is now changed to: " + cyphertext);       
         }
        cyphertext = cyphertext.replace(" ", "");
        cyphertext = cyphertext.toUpperCase();
        System.out.println (cyphertext);
    }

    //Shifts letters down a row
    public static String verticalEncode(ArrayList <Integer> coords, char [][] cipher){
        String str = "";
        int a = coords.get(0)+1;
        int b = coords.get(2)+1;
        if (a==5) a = 0;
        if (b==5) b = 0;
        char char1 = cipher[a][coords.get(1)];
        char char2 = cipher[b][coords.get(3)];
        str = Character.toString(char1) + Character.toString (char2);
        return str;
    }
    //Shifts letters to the right (down a column)
    public static String horizontalEncode(ArrayList <Integer> coords, char [][] cipher){
        String str = "";
        int a = coords.get(1)+1;
        int b = coords.get(3)+1;
        if (a==5) a = 0;
        if (b==5) b = 0;
        char char1 = cipher[coords.get(0)][a];
        char char2 = cipher[coords.get(2)][b];
        str = Character.toString(char1) + Character.toString (char2);
        return str;
    }
    //SWITCHES COLUMN NUMBER // is the same as reg decode so I did not write another function
    public static String regularEncode(ArrayList <Integer> coords, char [][] cipher){
        String str = "";
        int a = coords.get(1);
        int b = coords.get(3);
        char char1 = cipher[coords.get(0)][b];
        char char2 = cipher[coords.get(2)][a];
        str = Character.toString(char1) + Character.toString (char2);
        return str;
    }
    //gives the array indices of the plaintext in the grid based on where they appear
    public static ArrayList<Integer> get_cols_rows (String s, char [][] cipher){
        ArrayList<Integer> indices = new ArrayList<Integer> (); // row, col, row,col
        char P = s.charAt (0); //1st character
        char Q = s.charAt (1); //2nd character
        int a = 0; //1st char's row
        int b = 0; //1st char's col
        int c = 0; //2nd char's row
        int d = 0; //2nd char's col

        for (int i = 0; i < 5; i++){ // i is row, j is col
            for (int j = 0; j <5; j++){
                if (cipher[i][j] == P) {
                    a = i;
                    b = j;
                }
                if (cipher[i][j] == Q) {
                    c = i;
                    d = j;
                }
            }
        }
        indices.add(a);
        indices.add(b);
        indices.add(c);
        indices.add(d);
        return indices;
    }

    // adds exs and spaces
    public static String add_exs (String plaintext){
        int i = 0;
        while (i < plaintext.length()){
            int j = plaintext.length();
            if ((i+1) >= j) break;
            if (plaintext.charAt(i) == plaintext.charAt(i+1)) plaintext = plaintext.substring(0, i+1) + "x" + plaintext.substring(i+1, j);
            i = i + 2;
        }
        int j = plaintext.length();        
        if (plaintext.length()%2 == 1) plaintext = plaintext + 'x';
        String str = "";
        for (int k =0; k < plaintext.length(); k =k + 2){
            str = str + plaintext.substring(k, k+2) + " ";
        }
        return str;
    }
    /**************************************************************************************************************************************** */
    // HERE'S WHERE THE DECODING STARTS!
    public static void decode (String cyphertext, char [][] cipher){
        cyphertext = cyphertext.toLowerCase();
        cyphertext = cyphertext.replace (" ", "");
        cyphertext = cyphertext.replace ("j", "i");
        cyphertext = add_spaces (cyphertext);
        //System.out.println (cyphertext);
        //System.out.println (cyphertext.length());
        String plaintext = "";

        for (int i = 0; i < cyphertext.length(); i=i+3){
            String str = cyphertext.substring (i, i + 2);
            ArrayList <Integer> coords = get_cols_rows(str, cipher);
            //System.out.println(str + " " + coords);
            if (coords.get(1) == coords.get(3)) plaintext = plaintext + horizontalDecode(coords, cipher) + " "; // if the columns of the chars are the same
            else{
                if (coords.get(0)== coords.get(2)) plaintext = plaintext + verticalDecode(coords, cipher) + " ";// if the row of the chars are the same
                else{plaintext = plaintext + regularEncode(coords, cipher) + " ";}
            }          
        }
        plaintext = plaintext.replace (" ", "");
        plaintext = plaintext.toUpperCase();
        System.out.println (plaintext);
    }
    //shifts up
    public static String verticalDecode(ArrayList <Integer> coords, char [][] cipher){
        String str = "";
        int a = coords.get(0)-1;
        int b = coords.get(2)-1;
        if (a==-1) a = 4;
        if (b==-1) b = 4;
        char char1 = cipher[a][coords.get(1)];
        char char2 = cipher[b][coords.get(3)];
        str = Character.toString(char1) + Character.toString (char2);
        return str;
    }
    //shift to the left
    public static String horizontalDecode(ArrayList <Integer> coords, char [][] cipher){
        String str = "";
        int a = coords.get(1)-1;
        int b = coords.get(3)-1;
        if (a==-1) a = 4;
        if (b==-1) b = 4;
        char char1 = cipher[coords.get(0)][a];
        char char2 = cipher[coords.get(2)][b];
        str = Character.toString(char1) + Character.toString (char2);
        return str;
    }
        // adds spaces only
        public static String add_spaces (String plaintext){
            String str = "";
            for (int k =0; k < plaintext.length(); k =k + 2){
                str = str + plaintext.substring(k, k+2) + " ";
            }
            return str;
        }
}
