//*****************************************************************************//
// Compilation: javac freq_analysis.java
// Execution: java freq_analysis.java <ciphertext>
// Dependencies: None
//****************************************************************************//
//import java.util.*;
public class freq_analysis{
    // global variables!
    public static String [] alphabet = {"a", "b", "c" , "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    public static double [] freqs = {0.0812, 0.0149, 0.0271, 0.0432, 0.1202, 0.0230, 0.0203, 0.0592, 
        0.0731, 0.0010, 0.0069, 0.0398, 0.0261, 0.0695, 0.0768, 0.0182, 0.0011, 0.0602, 0.0628, 0.0910, 0.0288, 0.0111, 0.0209, 0.0017, 0.0211, 0.0007};
    public static void main (String [] args){
        String text = args[0]; //"b ehox fr fhf laxl max uxlm";
        text = text.replace(" ", "");
        text = text.toLowerCase();
        //System.out.println (letterFreq (text, "b"));
        System.out.println (All_letterFreq(text));
    }
    // calculates the freuqncy of one letter in the entire text (goes from a to z)
    public static double letterFreq (String text, String y) {
        double n = text.length();
        double count = 0.0;
        for (int i =0; i < text.length(); i++){
            String x = Character.toString (text.charAt (i));
            if (x.equals(y)) count++;
        }
        return count/n ;
    }
    // calculates the difference between the all letter frequences in the text and the averaged out letter frequencies in the english language
    // returns the sum of all the differences
    public static double All_letterFreq (String text){
        double sum = 0.0;
        for (int i =0; i < 26; i++){
            double frecuency = letterFreq(text, alphabet[i]);
            System.out.println (alphabet[i] + ": " +  frecuency);
            double diff = pythagorean(frecuency, freqs[i]);
            sum = sum + diff;
        }
        return sum;
    }
    //pythagorean square
    public static double pythagorean (double x, double y){
        return Math.sqrt (x * x + y * y);
    }
}