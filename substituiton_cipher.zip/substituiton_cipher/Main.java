public class Main {
    public static void main (String args []){
        // global array containing the alphabet
    public static String [] alphabet = {"a", "b", "c" , "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    public static void main (String [] args){
        //String text = "defend the east wall of the castle";
        String text = args [0];//"l syto ue uyu vbov wbo iovw";//"a ndsi ow odo reir cei hirc";//"giuifg cei iprc tpnn du cei qprcni";
        String key = args[1];//"giqaojxblkmsurynfzvwctdpeh"; //"phqgiumeaylnofdxjkrcvstzwb";
        String [] cipher = parseKey (key); 
        System.out.println("Cyphertext is: "+ decrypt(text, cipher));
    }
    public static String [] parseKey (String key){
        String [] cipher = new String [26];
        for (int i = 0; i < 26; i++){
            cipher[i] = Character.toString (key.charAt(i));
        }
        return cipher;
    }
    //encrypts the plaintezt with the given key
    public static String encrypt (String plaintext, String [] cipher){
        String ciphertext = "";
        for (int i = 0; i < plaintext.length(); i++){
            char c = plaintext.charAt(i);
            if (Character.toString(c).equals(" ")) ciphertext = ciphertext + " ";
            else{
                int m = getIndex(c, alphabet);
                String e = cipher[m];
                ciphertext = ciphertext + e;
                //System.out.println (m + " " + cipher[m]);
                //System.out.println ("Ciphertext is: " + ciphertext);
            }
        }
        return ciphertext;
    }
    public static int getIndex (char c, String [] arr){
        int k = -1;
        for (int i=0; i<26; i++){
            if (arr[i].equals(Character.toString(c))) {
                k = i;
                //System.out.println("yes! "+ alphabet[i] + c );
            }
            //else{System.out.println( i + "no");}
        }
        return k;
    }
    // decrypts any monoalphabetic ciphertext with the given key
    public static String decrypt (String cyphertext, String [] cipher){
        String plaintext = "";
        for (int i = 0; i < cyphertext.length(); i++){
            char c = cyphertext.charAt(i);
            if (Character.toString(c).equals(" ")) plaintext = plaintext + " ";
            else{
                int m = getIndex(c, cipher);
                String e = alphabet[m];
                plaintext = plaintext + e;
                //System.out.println (m + " " + cipher[m]);
                //System.out.println ("Ciphertext is: " + plaintext);
            }
        }
        return plaintext;
    }
    }
}