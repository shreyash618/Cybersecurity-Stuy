This project is divided into three files to separate the functions of each program and make it easier to work with.
caesarshift.java is the main project file since it calls the other two's methods. 

How to use:
javac caesarshift.java
java caesarshift <text to decode>

You can also try:
javac sub.java
java sub.java <text> <key

javac freq_analysis.java
java freq_analysis <ciphertext>

caesarshift.java will decode any (simple substituion) caesarshift-encrypted text and will print the most likely shift using frequency anaylsis.

sub.java is a program that contains methods that decrypt and encrypt messages using a given key.

freq_analysis uses frequency analysis to determine the "fit" of a plaintext/ciphertext. It uses pythagorean theorem to determine the difference between the letter frequencies
in the ciphertext and the avearge language frequencies, and adds them up to make one sum.