//*****************************************************************************//
// Compilation: javac caesarshift.java
// Execution: java caesarshift.java <ciphertext>
// *Note: no punctuation!
// Dependencies: sub.java and freq_analysis.java must be in your current working directory
//****************************************************************************//
import java.util.*;
public class caesarshift {
    //global variables
    public static String [] alphabet = {"a", "b", "c" , "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    public static double [] arr = new double [26];
    public static void main (String [] args){
        //test case 1: thismessagewasencryptedusingacaesarshiftcipher
        //String text = "WKLV PHVVDJH ZDV HQFUBSWHG XVLQJ D FDHVDU VKLIW FLSKHU";

        //test case 2: thisisashortenoughtextthatisencryptedwithasimpleshiftcipher
        //String text = "HVWG WG O GVCFH SBCIUV HSLH HVOH WG SBQFMDHSR KWHV O GWADZS GVWTH QWDVSF";

        //test case 3: thequickbrownfoxjumpsoverthelayzdog
        //String text = "UIFRVJDLCSPXOGPYKVNQTPWFSUIFMBZAEPH";
        String text = args [0];
        text = text.replace(" ", "");
        text = text.toLowerCase();
        text = text.replaceAll(".!?/'-&@#$%*():;,", "");
        //String [] shift = permute (1);
        //for (int i =0; i< 26; i++) {
        //    System.out.print (shift[i]);
        //}
        //System.out.println ("Plaintext is: " + sub.decrypt(text, shift));
        permuteAll(text);
        System.out.println ("The best subsitituition is: +" + BestShift());
        System.out.println (sub.decrypt(text, permute(BestShift())));

    }
    public static String [] permute (int m){
        String [] shift = new String [26];
        for (int i =0; i < 26; i++){
            int value = i + m;
            if (value >= 26) value = value - 26;
            if (value < 0) value = value + 26;
            shift[value] = alphabet[i];
        }
        return shift;
    }
    // trys all 26 subsitiution shifts
    public static void permuteAll(String text){
        for (int i =0; i < 26; i++) {
            String [] shift = permute (i);
            String plaintext = sub.decrypt(text, shift);
            arr [i] = freq_analysis.All_letterFreq(plaintext); //stores each decrypted text's frequnency analysis results;
        }
    }
    public static int BestShift(){
        double min_Value = (double) Integer.MAX_VALUE; //sets the 
        int min_Index = 0;
        for (int i = 0; i < 26; i++){
            if (arr[i] < min_Value) {
                min_Value = arr[i];
                min_Index  = i;
            }
        }
        return min_Index;
    }

}